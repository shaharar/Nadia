Read Me:

Name: Shahar Arad (��� ���)
ID: 311505895

My site is about Nadia Comaneci - a Romanian olympic gymnast, whom I admire from a young age.  

URL:
https://shaharar.github.io/Nadia/


Please notice the following:

1. If you can't see the Like button, you should remove the site's security block (beside the url, on the left).
2. Nadia's Photos - you can transfer the photos by the red scroll bar below them.
3. Contact Me - after filling the details and pressing "send", the message will be sent automatically to my gmail account (you should see a feedback of accepting your comment). 
4. I decided not to promote my site in the social networks.


Enjoy :)